
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Heart, Sparkles, Music, Star, Flower2, HeartHandshake } from 'lucide-react';
import confetti from 'canvas-confetti';
import { GoogleGenAI } from "@google/genai";

// Simple custom component for the background
const FloatingHearts = () => {
  const [hearts, setHearts] = useState<any[]>([]);

  useEffect(() => {
    const newHearts = Array.from({ length: 25 }).map((_, i) => ({
      id: i,
      left: `${Math.random() * 100}%`,
      size: `${Math.random() * (40 - 15) + 15}px`,
      delay: `${Math.random() * 15}s`,
      duration: `${Math.random() * (20 - 10) + 10}s`,
    }));
    setHearts(newHearts);
  }, []);

  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
      {hearts.map((heart) => (
        <div
          key={heart.id}
          className="heart-particle text-rose-300 opacity-40"
          style={{
            left: heart.left,
            fontSize: heart.size,
            animationDelay: heart.delay,
            animationDuration: heart.duration,
          }}
        >
          ❤️
        </div>
      ))}
    </div>
  );
};

export default function App() {
  const [isAccepted, setIsAccepted] = useState(false);
  const [noButtonPos, setNoButtonPos] = useState({ x: 0, y: 0 });
  const [moveCount, setMoveCount] = useState(0);
  const [sweetMessage, setSweetMessage] = useState("");
  const [isLoadingMessage, setIsLoadingMessage] = useState(false);

  // Gemini API integration for a personalized sweet note when she says Yes
  const generateSweetNote = useCallback(async () => {
    setIsLoadingMessage(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: "Write a very short, poetic, and romantic 2-line message for my girlfriend 'Jaanu' who just agreed to be my Valentine. Make it super sweet and charming.",
      });
      setSweetMessage(response.text || "You've made me the happiest person alive! ❤️");
    } catch (error) {
      console.error("Failed to fetch sweet message:", error);
      setSweetMessage("I promise to make every day feel like Valentine's Day with you! ❤️");
    } finally {
      setIsLoadingMessage(false);
    }
  }, []);

  const handleNoButtonHover = () => {
    const maxX = window.innerWidth - 150;
    const maxY = window.innerHeight - 50;
    
    // Calculate a new random position that isn't too close to the current one
    const newX = Math.random() * maxX;
    const newY = Math.random() * maxY;
    
    setNoButtonPos({ x: newX, y: newY });
    setMoveCount(prev => prev + 1);
  };

  const handleYesClick = () => {
    setIsAccepted(true);
    confetti({
      particleCount: 150,
      spread: 70,
      origin: { y: 0.6 },
      colors: ['#ff4d6d', '#ff758f', '#ffb3c1', '#ffffff']
    });
    generateSweetNote();
  };

  const getNoButtonText = () => {
    const texts = [
      "No", "Are you sure?", "Think again!", "Puh-lease?", 
      "You're misclicking!", "Try the other one!", "Calculated mistake?", 
      "Wait, what?", "Jaanu, please!", "Not an option!"
    ];
    return texts[Math.min(moveCount, texts.length - 1)];
  };

  return (
    <div className="relative min-h-screen w-full flex items-center justify-center bg-gradient-to-br from-rose-100 via-pink-50 to-rose-200 overflow-hidden px-4">
      <FloatingHearts />

      <AnimatePresence mode="wait">
        {!isAccepted ? (
          <motion.div
            key="proposal"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 1.2 }}
            className="z-10 w-full max-w-lg bg-white/70 backdrop-blur-md rounded-3xl shadow-2xl p-8 md:p-12 border-4 border-rose-200 text-center relative"
          >
            <div className="absolute -top-12 left-1/2 -translate-x-1/2 bg-rose-500 p-4 rounded-full shadow-lg border-4 border-white">
              <Heart className="w-12 h-12 text-white fill-current animate-pulse" />
            </div>

            <motion.h1 
              initial={{ y: 20 }}
              animate={{ y: 0 }}
              className="mt-8 text-4xl md:text-5xl font-romantic text-rose-600 font-bold mb-4"
            >
              Hi Jaanu ❤️
            </motion.h1>

            <p className="text-xl text-gray-700 font-medium mb-8 leading-relaxed">
              Every moment with you feels like a dream I never want to wake up from. 
              My heart beats just for you.
              <br />
              <span className="font-bold text-rose-500 text-2xl mt-4 block">
                Will you be my Valentine?
              </span>
            </p>

            <div className="flex flex-col md:flex-row items-center justify-center gap-6 relative min-h-[100px]">
              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={handleYesClick}
                className="px-10 py-4 bg-rose-500 text-white rounded-full font-bold text-xl shadow-lg hover:bg-rose-600 transition-colors flex items-center gap-2 group"
              >
                YES! <Heart className="w-5 h-5 fill-current group-hover:scale-125 transition-transform" />
              </motion.button>

              <motion.button
                style={{
                  position: moveCount > 0 ? 'fixed' : 'relative',
                  left: moveCount > 0 ? noButtonPos.x : 'auto',
                  top: moveCount > 0 ? noButtonPos.y : 'auto',
                  zIndex: 50
                }}
                onMouseEnter={handleNoButtonHover}
                onClick={handleNoButtonHover}
                className="px-10 py-4 bg-gray-200 text-gray-600 rounded-full font-bold text-xl shadow-md transition-all duration-200 whitespace-nowrap"
              >
                {getNoButtonText()}
              </motion.button>
            </div>

            <div className="mt-12 flex justify-center gap-4 text-rose-300">
              <Sparkles className="w-6 h-6 animate-bounce" />
              <Flower2 className="w-6 h-6 animate-spin-slow" />
              <Music className="w-6 h-6 animate-pulse" />
            </div>
          </motion.div>
        ) : (
          <motion.div
            key="success"
            initial={{ opacity: 0, scale: 0.5, rotate: -10 }}
            animate={{ opacity: 1, scale: 1, rotate: 0 }}
            className="z-10 w-full max-w-2xl text-center"
          >
            <div className="bg-white/80 backdrop-blur-lg rounded-[2rem] shadow-2xl p-10 md:p-16 border-8 border-double border-rose-300 relative overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-transparent via-rose-500 to-transparent"></div>
              
              <div className="flex justify-center mb-6">
                <div className="relative">
                  <motion.div 
                    animate={{ scale: [1, 1.2, 1] }} 
                    transition={{ repeat: Infinity, duration: 2 }}
                  >
                    <HeartHandshake className="w-24 h-24 text-rose-500" />
                  </motion.div>
                  <motion.div
                    className="absolute -top-4 -right-4"
                    animate={{ rotate: 360 }}
                    transition={{ repeat: Infinity, duration: 10, ease: "linear" }}
                  >
                    <Star className="w-10 h-10 text-yellow-400 fill-current" />
                  </motion.div>
                </div>
              </div>

              <h2 className="text-5xl md:text-6xl font-romantic text-rose-600 mb-6">
                Yay! I Knew It! 💖
              </h2>

              <p className="text-2xl text-rose-800 font-medium mb-8">
                You've made me the happiest person in the world, Jaanu.
              </p>

              <div className="p-6 bg-rose-50/50 rounded-2xl border border-rose-100 italic text-gray-600">
                {isLoadingMessage ? (
                  <div className="flex items-center justify-center gap-2">
                    <div className="w-2 h-2 bg-rose-400 rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-rose-400 rounded-full animate-bounce delay-75"></div>
                    <div className="w-2 h-2 bg-rose-400 rounded-full animate-bounce delay-150"></div>
                  </div>
                ) : (
                  <motion.p
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="text-xl"
                  >
                    "{sweetMessage}"
                  </motion.p>
                )}
              </div>

              <div className="mt-10 grid grid-cols-3 gap-4">
                {[...Array(3)].map((_, i) => (
                  <motion.div
                    key={i}
                    initial={{ y: 20, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ delay: 0.2 * i }}
                    className="rounded-xl overflow-hidden shadow-md"
                  >
                    <img 
                      src={`https://picsum.photos/seed/${i + 50}/300/300`} 
                      alt="Cute vibes" 
                      className="w-full h-24 object-cover"
                    />
                  </motion.div>
                ))}
              </div>

              <p className="mt-8 text-rose-400 font-bold uppercase tracking-widest text-sm flex items-center justify-center gap-2">
                <Heart className="w-4 h-4 fill-current" /> Together Forever <Heart className="w-4 h-4 fill-current" />
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="fixed bottom-4 right-4 text-rose-300 opacity-30 text-xs pointer-events-none">
        Made with ❤️ for Jaanu
      </div>
    </div>
  );
}
